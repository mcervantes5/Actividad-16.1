import 'package:flutter/material.dart';

class Education extends StatelessWidget {
  const Education({super.key});

  @override
  Widget build(BuildContext context) {
    return Center(child: Container( child: Text("Bienvenido a Education", style: TextStyle(fontSize: 22.0, color: Colors.red),),));}
  }